"use client"

import { useCallback, useEffect, useState } from "react"

/** Conversion + business rules */
export const POINTS_PER_USD = 10000
export const POINTS_PER_AD = 20
export const MIN_WITHDRAWAL_USD = 255
export const MIN_WITHDRAWAL_POINTS = MIN_WITHDRAWAL_USD * POINTS_PER_USD

export type WithdrawalStatus = "Pending" | "Approved"

export type Withdrawal = {
  id: string
  provider: string
  account: string
  points: number
  amountUsd: number
  status: WithdrawalStatus
  date: number
}

type StoreState = {
  points: number
  adsWatched: number
  withdrawals: Withdrawal[]
}

const STORAGE_KEY = "watch-and-win:v1"
const EVENT = "watch-and-win:update"

const defaultState: StoreState = {
  points: 0,
  adsWatched: 0,
  withdrawals: [],
}

function readState(): StoreState {
  if (typeof window === "undefined") return defaultState
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return defaultState
    const parsed = JSON.parse(raw) as Partial<StoreState>
    return {
      points: parsed.points ?? 0,
      adsWatched: parsed.adsWatched ?? 0,
      withdrawals: parsed.withdrawals ?? [],
    }
  } catch {
    return defaultState
  }
}

function writeState(state: StoreState) {
  if (typeof window === "undefined") return
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  window.dispatchEvent(new Event(EVENT))
}

export function pointsToUsd(points: number) {
  return points / POINTS_PER_USD
}

export function formatUsd(usd: number) {
  return usd.toLocaleString("en-US", { style: "currency", currency: "USD" })
}

/** Shared store hook backed by localStorage, synced across components/tabs. */
export function useStore() {
  const [state, setState] = useState<StoreState>(defaultState)
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    setState(readState())
    setHydrated(true)

    const sync = () => setState(readState())
    window.addEventListener(EVENT, sync)
    window.addEventListener("storage", sync)
    return () => {
      window.removeEventListener(EVENT, sync)
      window.removeEventListener("storage", sync)
    }
  }, [])

  const addAdReward = useCallback(() => {
    const next = readState()
    next.points += POINTS_PER_AD
    next.adsWatched += 1
    writeState(next)
    return POINTS_PER_AD
  }, [])

  const requestWithdrawal = useCallback(
    (provider: string, account: string) => {
      const next = readState()
      if (next.points < MIN_WITHDRAWAL_POINTS) return null

      // Withdraw the whole available balance rounded down to full dollars.
      const fullDollars = Math.floor(next.points / POINTS_PER_USD)
      const points = fullDollars * POINTS_PER_USD
      const amountUsd = fullDollars

      const withdrawal: Withdrawal = {
        id:
          typeof crypto !== "undefined" && "randomUUID" in crypto
            ? crypto.randomUUID()
            : String(Date.now()),
        provider,
        account,
        points,
        amountUsd,
        status: "Pending",
        date: Date.now(),
      }

      next.points -= points
      next.withdrawals = [withdrawal, ...next.withdrawals]
      writeState(next)
      return withdrawal
    },
    [],
  )

  return {
    hydrated,
    points: state.points,
    adsWatched: state.adsWatched,
    withdrawals: state.withdrawals,
    balanceUsd: pointsToUsd(state.points),
    canWithdraw: state.points >= MIN_WITHDRAWAL_POINTS,
    addAdReward,
    requestWithdrawal,
  }
}
