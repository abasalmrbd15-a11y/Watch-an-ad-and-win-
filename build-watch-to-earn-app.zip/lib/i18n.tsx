"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react"

export type Lang = "ar" | "en"

type Dict = Record<string, string>

const translations: Record<Lang, Dict> = {
  en: {
    // App / header
    "app.name": "Watch & Win",
    "app.tagline": "Watch ads, earn cash",
    "lang.toggle": "العربية",
    "lang.label": "Switch language",

    // Nav
    "nav.home": "Home",
    "nav.wallet": "Wallet",
    "nav.history": "History",

    // Home
    "home.totalPoints": "Your total points",
    "home.available": "available",
    "home.heroTitle": "Watch a video, earn instantly",
    "home.heroSubtitle": "Earn {points} points for every ad you watch to the end.",
    "home.watchButton": "Watch Ad & Earn",
    "home.adsWatched": "Ads watched",
    "home.balance": "Balance",
    "home.howItWorks": "How it works",
    "home.conversion": "Every {points} points = {usd} USD",
    "home.step1pre": "Tap",
    "home.step1mid": "Watch Ad & Earn",
    "home.step1post": "and view the full video.",
    "home.step2": "Points are added to your balance automatically.",
    "home.step3": "Reach {usd} and cash out to your e-wallet.",

    // Wallet
    "wallet.available": "Available balance",
    "wallet.pointsSuffix": "points",
    "wallet.remaining": "{points} more points until you can withdraw.",
    "wallet.minLabel": "Minimum withdrawal:",
    "wallet.minValue": "{usd} ({points} points)",
    "wallet.requestTitle": "Request a payout",
    "wallet.provider": "E-Wallet provider",
    "wallet.providerPlaceholder": "Select a provider",
    "wallet.account": "Phone number / Account ID",
    "wallet.accountPlaceholder": "e.g. 010xxxxxxxx or wallet ID",
    "wallet.requestButton": "Request Withdrawal",
    "wallet.locked": "Reach {usd} to unlock",
    "wallet.formHint": "Select a provider and enter your account to continue.",
    "wallet.toastTitle": "Withdrawal requested",
    "wallet.toastDesc": "{usd} to {provider} is now pending.",
    "wallet.toastError": "You haven't reached the minimum withdrawal yet.",

    // History
    "history.title": "Transaction history",
    "history.subtitle": "Track the status of your withdrawal requests.",
    "history.empty": "No withdrawals yet",
    "history.emptyDesc": "Once you request a payout, it will appear here with its status.",
    "status.Pending": "Pending",
    "status.Approved": "Approved",

    // Ad player
    "ad.label": "Ad",
    "ad.playing": "Sponsored video playing…",
    "ad.finished": "Ad finished",
    "ad.closeLabel": "Close ad",
    "ad.earned": "+{points} points earned!",
    "ad.earnedDesc": "Your reward has been added to your balance.",
    "ad.collect": "Collect & Continue",
    "ad.watchHintPre": "Watch the full ad to earn",
    "ad.watchHintPoints": "{points} points",
    "ad.watchHintPost": ". Please don't close the window.",
    "ad.rewardToast": "+{points} points added!",
  },
  ar: {
    // App / header
    "app.name": "شاهد واربح",
    "app.tagline": "شاهد الإعلانات واربح المال",
    "lang.toggle": "English",
    "lang.label": "تغيير اللغة",

    // Nav
    "nav.home": "الرئيسية",
    "nav.wallet": "المحفظة",
    "nav.history": "السجل",

    // Home
    "home.totalPoints": "إجمالي نقاطك",
    "home.available": "متاح",
    "home.heroTitle": "شاهد فيديو واربح فوراً",
    "home.heroSubtitle": "احصل على {points} نقطة عن كل إعلان تشاهده حتى النهاية.",
    "home.watchButton": "شاهد الإعلان واربح",
    "home.adsWatched": "الإعلانات المشاهدة",
    "home.balance": "الرصيد",
    "home.howItWorks": "كيف يعمل التطبيق",
    "home.conversion": "كل {points} نقطة = {usd} دولار",
    "home.step1pre": "اضغط",
    "home.step1mid": "شاهد الإعلان واربح",
    "home.step1post": "وشاهد الفيديو كاملاً.",
    "home.step2": "تُضاف النقاط إلى رصيدك تلقائياً.",
    "home.step3": "اوصل إلى {usd} واسحب أرباحك إلى محفظتك الإلكترونية.",

    // Wallet
    "wallet.available": "الرصيد المتاح",
    "wallet.pointsSuffix": "نقطة",
    "wallet.remaining": "تحتاج {points} نقطة إضافية حتى تتمكن من السحب.",
    "wallet.minLabel": "الحد الأدنى للسحب:",
    "wallet.minValue": "{usd} ({points} نقطة)",
    "wallet.requestTitle": "طلب سحب الأرباح",
    "wallet.provider": "مزود المحفظة الإلكترونية",
    "wallet.providerPlaceholder": "اختر المزود",
    "wallet.account": "رقم الهاتف / معرّف الحساب",
    "wallet.accountPlaceholder": "مثال: 010xxxxxxxx أو معرّف المحفظة",
    "wallet.requestButton": "طلب السحب",
    "wallet.locked": "اوصل إلى {usd} لفتح السحب",
    "wallet.formHint": "اختر المزود وأدخل حسابك للمتابعة.",
    "wallet.toastTitle": "تم إرسال طلب السحب",
    "wallet.toastDesc": "{usd} إلى {provider} قيد الانتظار الآن.",
    "wallet.toastError": "لم تصل إلى الحد الأدنى للسحب بعد.",

    // History
    "history.title": "سجل المعاملات",
    "history.subtitle": "تابع حالة طلبات السحب الخاصة بك.",
    "history.empty": "لا توجد عمليات سحب بعد",
    "history.emptyDesc": "بمجرد طلب السحب، سيظهر هنا مع حالته.",
    "status.Pending": "قيد الانتظار",
    "status.Approved": "تمت الموافقة",

    // Ad player
    "ad.label": "إعلان",
    "ad.playing": "جارٍ تشغيل الفيديو الإعلاني…",
    "ad.finished": "انتهى الإعلان",
    "ad.closeLabel": "إغلاق الإعلان",
    "ad.earned": "ربحت {points} نقطة!",
    "ad.earnedDesc": "تمت إضافة مكافأتك إلى رصيدك.",
    "ad.collect": "استلم وتابع",
    "ad.watchHintPre": "شاهد الإعلان كاملاً لتربح",
    "ad.watchHintPoints": "{points} نقطة",
    "ad.watchHintPost": ". من فضلك لا تغلق النافذة.",
    "ad.rewardToast": "تمت إضافة {points} نقطة!",
  },
}

type I18nContextValue = {
  lang: Lang
  dir: "rtl" | "ltr"
  setLang: (lang: Lang) => void
  toggleLang: () => void
  t: (key: string, vars?: Record<string, string | number>) => string
}

const I18nContext = createContext<I18nContextValue | null>(null)

const STORAGE_KEY = "watch-and-win:lang"

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar")

  // Load saved language preference.
  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY) as Lang | null
    if (saved === "ar" || saved === "en") setLangState(saved)
  }, [])

  // Keep <html> lang/dir in sync.
  useEffect(() => {
    const dir = lang === "ar" ? "rtl" : "ltr"
    document.documentElement.lang = lang
    document.documentElement.dir = dir
  }, [lang])

  const setLang = useCallback((next: Lang) => {
    setLangState(next)
    window.localStorage.setItem(STORAGE_KEY, next)
  }, [])

  const toggleLang = useCallback(() => {
    setLangState((prev) => {
      const next = prev === "ar" ? "en" : "ar"
      window.localStorage.setItem(STORAGE_KEY, next)
      return next
    })
  }, [])

  const t = useCallback(
    (key: string, vars?: Record<string, string | number>) => {
      let str = translations[lang][key] ?? translations.en[key] ?? key
      if (vars) {
        for (const [k, v] of Object.entries(vars)) {
          str = str.replace(new RegExp(`\\{${k}\\}`, "g"), String(v))
        }
      }
      return str
    },
    [lang],
  )

  return (
    <I18nContext.Provider
      value={{ lang, dir: lang === "ar" ? "rtl" : "ltr", setLang, toggleLang, t }}
    >
      {children}
    </I18nContext.Provider>
  )
}

export function useI18n() {
  const ctx = useContext(I18nContext)
  if (!ctx) throw new Error("useI18n must be used within an I18nProvider")
  return ctx
}
