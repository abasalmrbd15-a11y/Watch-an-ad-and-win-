"use client"

import { useCallback, useState } from "react"
import { Home, Wallet, History as HistoryIcon, Coins, Languages } from "lucide-react"
import { toast } from "sonner"
import { AdPlayer } from "@/components/ad-player"
import { HomeScreen } from "@/components/home-screen"
import { WalletScreen } from "@/components/wallet-screen"
import { HistoryScreen } from "@/components/history-screen"
import { POINTS_PER_AD, useStore } from "@/lib/store"
import { useI18n } from "@/lib/i18n"
import { cn } from "@/lib/utils"

type Tab = "home" | "wallet" | "history"

const TABS: { id: Tab; labelKey: string; icon: typeof Home }[] = [
  { id: "home", labelKey: "nav.home", icon: Home },
  { id: "wallet", labelKey: "nav.wallet", icon: Wallet },
  { id: "history", labelKey: "nav.history", icon: HistoryIcon },
]

export default function Page() {
  const [tab, setTab] = useState<Tab>("home")
  const [adOpen, setAdOpen] = useState(false)
  const { addAdReward } = useStore()
  const { t, toggleLang } = useI18n()

  const handleReward = useCallback(() => {
    addAdReward()
    toast.success(t("ad.rewardToast", { points: POINTS_PER_AD }))
  }, [addAdReward, t])

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-background/80 px-5 py-4 backdrop-blur">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
            <Coins className="h-5 w-5 text-primary-foreground" aria-hidden="true" />
          </div>
          <div>
            <h1 className="text-base font-bold leading-tight text-foreground">
              {t("app.name")}
            </h1>
            <p className="text-xs text-muted-foreground">{t("app.tagline")}</p>
          </div>
        </div>
        <button
          type="button"
          onClick={toggleLang}
          aria-label={t("lang.label")}
          className="flex items-center gap-1.5 rounded-full border border-border bg-secondary px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
        >
          <Languages className="h-4 w-4" aria-hidden="true" />
          {t("lang.toggle")}
        </button>
      </header>

      {/* Content */}
      <main className="flex-1 px-5 py-6 pb-28">
        {tab === "home" && <HomeScreen onWatchAd={() => setAdOpen(true)} />}
        {tab === "wallet" && <WalletScreen />}
        {tab === "history" && <HistoryScreen />}
      </main>

      {/* Bottom navigation */}
      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto max-w-md border-t border-border bg-card/95 backdrop-blur">
        <div className="grid grid-cols-3">
          {TABS.map(({ id, labelKey, icon: Icon }) => {
            const active = tab === id
            return (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex flex-col items-center gap-1 py-3 text-xs font-medium transition-colors",
                  active
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="h-5 w-5" aria-hidden="true" />
                {t(labelKey)}
              </button>
            )
          })}
        </div>
      </nav>

      <AdPlayer
        open={adOpen}
        onClose={() => setAdOpen(false)}
        onReward={handleReward}
      />
    </div>
  )
}
