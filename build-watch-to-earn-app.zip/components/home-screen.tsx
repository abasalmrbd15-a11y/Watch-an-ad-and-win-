"use client"

import { Coins, PlayCircle, Sparkles, TrendingUp, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  POINTS_PER_AD,
  POINTS_PER_USD,
  formatUsd,
  useStore,
} from "@/lib/store"
import { useI18n } from "@/lib/i18n"

type HomeScreenProps = {
  onWatchAd: () => void
}

export function HomeScreen({ onWatchAd }: HomeScreenProps) {
  const { points, adsWatched, balanceUsd, hydrated } = useStore()
  const { t } = useI18n()

  return (
    <div className="space-y-6">
      {/* Balance hero */}
      <section className="rounded-3xl border border-border bg-card p-6 text-center shadow-lg">
        <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-xs font-medium text-muted-foreground">
          <Sparkles className="h-3.5 w-3.5 text-accent" aria-hidden="true" />
          {t("home.totalPoints")}
        </div>
        <div className="flex items-center justify-center gap-2">
          <Coins className="h-8 w-8 text-accent" aria-hidden="true" />
          <span className="text-5xl font-extrabold tabular-nums tracking-tight text-foreground">
            {hydrated ? points.toLocaleString() : "—"}
          </span>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">
          ≈{" "}
          <span className="font-semibold text-primary">
            {formatUsd(balanceUsd)}
          </span>{" "}
          {t("home.available")}
        </p>
      </section>

      {/* Watch ad CTA */}
      <section className="rounded-3xl border border-primary/30 bg-primary/10 p-6 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/20">
          <PlayCircle className="h-9 w-9 text-primary" aria-hidden="true" />
        </div>
        <h2 className="text-balance text-xl font-bold text-foreground">
          {t("home.heroTitle")}
        </h2>
        <p className="mt-1 text-pretty text-sm text-muted-foreground">
          {t("home.heroSubtitle", { points: POINTS_PER_AD })}
        </p>
        <Button
          onClick={onWatchAd}
          size="lg"
          className="mt-5 h-14 w-full text-base font-bold"
        >
          <PlayCircle className="h-5 w-5" aria-hidden="true" />
          {t("home.watchButton")}
        </Button>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <PlayCircle className="h-4 w-4" aria-hidden="true" />
            <span className="text-xs font-medium">{t("home.adsWatched")}</span>
          </div>
          <p className="mt-2 text-2xl font-bold tabular-nums text-foreground">
            {hydrated ? adsWatched.toLocaleString() : "—"}
          </p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Wallet className="h-4 w-4" aria-hidden="true" />
            <span className="text-xs font-medium">{t("home.balance")}</span>
          </div>
          <p className="mt-2 text-2xl font-bold tabular-nums text-primary">
            {hydrated ? formatUsd(balanceUsd) : "—"}
          </p>
        </div>
      </section>

      {/* How it works */}
      <section className="rounded-3xl border border-border bg-card p-5">
        <div className="mb-3 flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-accent" aria-hidden="true" />
          <h3 className="text-sm font-semibold text-foreground">{t("home.howItWorks")}</h3>
        </div>
        <p className="rounded-xl bg-accent/10 px-4 py-3 text-center text-sm font-semibold text-foreground">
          {t("home.conversion", {
            points: POINTS_PER_USD.toLocaleString(),
            usd: formatUsd(1),
          })}
        </p>
        <ol className="mt-4 space-y-3 text-sm text-muted-foreground">
          <li className="flex gap-3">
            <Step n={1} />
            <span>
              {t("home.step1pre")}{" "}
              <span className="font-medium text-foreground">
                {t("home.step1mid")}
              </span>{" "}
              {t("home.step1post")}
            </span>
          </li>
          <li className="flex gap-3">
            <Step n={2} />
            {t("home.step2")}
          </li>
          <li className="flex gap-3">
            <Step n={3} />
            {t("home.step3", { usd: formatUsd(1) })}
          </li>
        </ol>
      </section>
    </div>
  )
}

function Step({ n }: { n: number }) {
  return (
    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">
      {n}
    </span>
  )
}
