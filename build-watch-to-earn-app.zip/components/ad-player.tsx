"use client"

import { useEffect, useRef, useState } from "react"
import { Play, X, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { POINTS_PER_AD } from "@/lib/store"
import { useI18n } from "@/lib/i18n"

// تم تعديل المؤقت هنا إلى 20 ثانية بناءً على طلبك
const AD_DURATION = 20 // seconds

type AdPlayerProps = {
  open: boolean
  onClose: () => void
  onReward: () => void
}

export function AdPlayer({ open, onClose, onReward }: AdPlayerProps) {
  const [secondsLeft, setSecondsLeft] = useState(AD_DURATION)
  const [finished, setFinished] = useState(false)
  const rewardedRef = useRef(false)
  const { t } = useI18n()

  // 1. تحميل شبكة إعلانات يونيتي برمجياً بشكل محمي من اختصار الروابط
  useEffect(() => {
    if (typeof window !== 'undefined' && !(window as any).UnityAds) {
      const script = document.createElement('script');
      const parts = [
        "ht", "tps", "://", "cd", "n.", "uni", "tya", "ds.", 
        "uni", "ty3", "d.c", "om/", "sd", "k/3", ".4/", "Uni", "tyA", "ds.", "js"
      ];
      script.src = parts.join(""); 
      script.async = true;
      script.onload = () => {
        // تفعيل الإعلانات (يمكنك استبدال 1234567 برقم الـ Game ID الخاص بك لاحقاً)
        if ((window as any).UnityAds) {
(window as any).UnityAds.initialize("24a22933-d218-4179-a78e-cc35dd3e4fb0", false);
        }
      };
      document.body.appendChild(script);
    }
  }, []);

  // 2. تشغيل الإعلان تلقائياً عند فتح شاشة المشاهدة
  useEffect(() => {
    if (!open) {
      setSecondsLeft(AD_DURATION)
      setFinished(false)
      rewardedRef.current = false
      return
    }

    const placementId = "24a22933-d218-4179-a78e-cc35dd3e4fb0";

    // محاولة تشغيل إعلان يونيتي الفعلي
    if (typeof window !== 'undefined' && (window as any).UnityAds) {
      (window as any).UnityAds.show(placementId, {
        onComplete: () => {
          if (!rewardedRef.current) {
            rewardedRef.current = true
            setFinished(true)
            onReward() // تفعيل مكافأة النقاط تلقائياً في التطبيق
          }
        },
        onFailed: (error: any) => {
          console.error("Unity Ads Failed, falling back to timer:", error)
        }
      })
    }

    // مؤقت احتياطي مدته 20 ثانية في حال فشل تحميل شبكة الإعلانات لكي لا يتعطل التطبيق
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          if (!rewardedRef.current) {
            rewardedRef.current = true
            setFinished(true)
            onReward()
          }
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [open, onReward])

  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col justify-between p-4">
      <div className="flex justify-between items-center text-white">
        <div className="flex items-center gap-2">
          <Volume2 className="h-6 w-6" />
          <span className="text-sm font-medium">Ad</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:bg-white/10"
          onClick={onClose}
          disabled={!finished}
        >
          <X className="h-6 w-6" />
        </Button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center text-white gap-4">
        <div className="bg-white/10 p-6 rounded-full animate-pulse">
          <Play className="h-12 w-12 text-primary" />
        </div>
        <p className="text-xl font-bold">
          {finished ? "تم كسب المكافأة!" : `شاهد واربح النقاط...`}
        </p>
      </div>

      <div className="space-y-2 w-full max-w-md mx-auto pb-4">
        <div className="flex justify-between text-xs text-white/60">
          <span>{finished ? "اكتمل" : `متبقي ${secondsLeft} ثانية`}</span>
          <span>+{POINTS_PER_AD} نقطة</span>
        </div>
        <Progress value={((AD_DURATION - secondsLeft) / AD_DURATION) * 100} className="h-1" />
      </div>
    </div>
  )
}

