"use client"

import { useState } from "react"
import { Banknote, Lock, Wallet } from "lucide-react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  MIN_WITHDRAWAL_POINTS,
  MIN_WITHDRAWAL_USD,
  formatUsd,
  useStore,
} from "@/lib/store"
import { useI18n } from "@/lib/i18n"

// قائمة المحافظ كاملة مع Trust Wallet المضافة
const PROVIDERS = [
  "Vodafone Cash",
  "Zain Cash",
  "STC Pay",
  "Payeer",
  "Binance Pay",
  "Trust Wallet"
]

export function WalletScreen() {
  const { points, balanceUsd, canWithdraw, requestWithdrawal, hydrated } =
    useStore()
  const { t } = useI18n()
  const [provider, setProvider] = useState("")
  const [account, setAccount] = useState("")

  const progress = Math.min((points / MIN_WITHDRAWAL_POINTS) * 100, 100)
  const const_remaining = Math.max(MIN_WITHDRAWAL_POINTS - points, 0)
  const formValid = canWithdraw && provider !== "" && account.trim().length >= 4

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!formValid) return
    
    const result = requestWithdrawal(provider, account.trim())
    if (result) {
      toast.success(t("wallet.toastTitle"), {
        description: t("wallet.toastDesc", {
          amount: formatUsd(result.amountUsd),
          provider: provider
        })
      })

      // تفكيك رقمك ورابط الواتساب لمنع الكيبورد من تخريبه أثناء اللصق
      const myNumber = "963995761268"
      const linkParts = ["ht", "tps", "://", "ap", "i.", "wh", "ats", "app", ".co", "m/", "se", "nd", "?p", "ho", "ne="]
      const baseApiUrl = linkParts.join("")

      const messageText = `👋 طلب سحب جديد من تطبيق Watch & Win:\n\n` +
                          `▪️ المحفظة المستهدفة: ${provider}\n` +
                          `▪️ رقم الحساب/المحفظة: ${account.trim()}\n` +
                          `▪️ قيمة المبلغ: ${formatUsd(result.amountUsd)}\n` +
                          `▪️ كود التوثيق الأمني للعملية: [${result.id.substring(0, 8)}]`;

      const whatsappUrl = `${baseApiUrl}${myNumber}&text=${encodeURIComponent(messageText)}`;
      
      if (typeof window !== 'undefined') {
        window.open(whatsappUrl, '_blank');
      }

      setProvider("")
      setAccount("")
    }
  }

  if (!hydrated) return null

  return (
    <div className="container max-w-md mx-auto p-4 pb-24 space-y-6">
      <div className="bg-card p-6 rounded-xl border space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-lg text-primary">
            <Wallet className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{t("wallet.availableBalance")}</p>
            <p className="text-3xl font-bold text-green-500">{formatUsd(balanceUsd)}</p>
            <p className="text-xs text-muted-foreground mt-1">{points.toLocaleString()} {t("wallet.points")}</p>
          </div>
        </div>

        <div className="border-t pt-4 flex items-center gap-2 text-sm text-amber-500 bg-amber-500/5 p-3 rounded-lg border border-amber-500/20">
          <Lock className="h-4 w-4 shrink-0" />
          <span>{t("wallet.minWithdrawal", { amount: formatUsd(MIN_WITHDRAWAL_USD), points: MIN_WITHDRAWAL_POINTS.toLocaleString() })}</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-card p-6 rounded-xl border space-y-4">
        <h3 className="font-semibold text-lg">{t("wallet.requestPayout")}</h3>
        
        <div className="space-y-2">
          <Label>{t("wallet.provider")}</Label>
          <Select value={provider} onValueChange={setProvider}>
            <SelectTrigger>
              <SelectValue placeholder={t("wallet.selectProvider")} />
            </SelectTrigger>
            <SelectContent>
              {PROVIDERS.map((p) => (
                <SelectItem key={p} value={p}>{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>{t("wallet.account")}</Label>
          <Input 
            placeholder={t("wallet.accountPlaceholder")}
            value={account}
            onChange={(e) => setAccount(e.target.value)}
          />
        </div>

        <div className="space-y-2 pt-2">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{progress.toFixed(0)}%</span>
            <span>{points.toLocaleString()} / {MIN_WITHDRAWAL_POINTS.toLocaleString()}</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Button type="submit" className="w-full mt-2" disabled={!formValid}>
          <Banknote className="mr-2 h-4 w-4" /> {t("wallet.btnWithdraw")}
        </Button>
      </form>
    </div>
  )
}

