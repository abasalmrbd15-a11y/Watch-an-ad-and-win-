"use client"

import { Clock, CheckCircle2, Receipt } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { formatUsd, useStore, type Withdrawal } from "@/lib/store"
import { useI18n } from "@/lib/i18n"

export function HistoryScreen() {
  const { withdrawals, hydrated } = useStore()
  const { t } = useI18n()

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-xl font-bold text-foreground">{t("history.title")}</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          {t("history.subtitle")}
        </p>
      </section>

      {!hydrated ? null : withdrawals.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed border-border bg-card/50 p-10 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-secondary">
            <Receipt className="h-6 w-6 text-muted-foreground" aria-hidden="true" />
          </div>
          <p className="font-medium text-foreground">{t("history.empty")}</p>
          <p className="max-w-xs text-sm text-muted-foreground">
            {t("history.emptyDesc")}
          </p>
        </div>
      ) : (
        <ul className="space-y-3">
          {withdrawals.map((w) => (
            <TransactionRow key={w.id} withdrawal={w} />
          ))}
        </ul>
      )}
    </div>
  )
}

function TransactionRow({ withdrawal }: { withdrawal: Withdrawal }) {
  const { t, lang } = useI18n()
  const approved = withdrawal.status === "Approved"
  const date = new Date(withdrawal.date).toLocaleDateString(
    lang === "ar" ? "ar-EG" : "en-US",
    {
      month: "short",
      day: "numeric",
      year: "numeric",
    },
  )

  return (
    <li className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4">
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-secondary">
          {approved ? (
            <CheckCircle2 className="h-5 w-5 text-primary" aria-hidden="true" />
          ) : (
            <Clock className="h-5 w-5 text-accent" aria-hidden="true" />
          )}
        </div>
        <div className="min-w-0">
          <p className="truncate font-semibold text-foreground">
            {withdrawal.provider}
          </p>
          <p className="truncate text-xs text-muted-foreground">
            {withdrawal.account} · {date}
          </p>
        </div>
      </div>

      <div className="flex flex-col items-end gap-1">
        <span className="font-bold tabular-nums text-foreground">
          {formatUsd(withdrawal.amountUsd)}
        </span>
        <Badge
          variant="outline"
          className={
            approved
              ? "border-primary/40 bg-primary/10 text-primary"
              : "border-accent/40 bg-accent/10 text-accent"
          }
        >
          {t(`status.${withdrawal.status}`)}
        </Badge>
      </div>
    </li>
  )
}
